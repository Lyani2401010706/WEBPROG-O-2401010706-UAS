<?php
$koneksi = mysqli_connect("localhost", "root", "", "musicfav");

if (!$koneksi) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>
