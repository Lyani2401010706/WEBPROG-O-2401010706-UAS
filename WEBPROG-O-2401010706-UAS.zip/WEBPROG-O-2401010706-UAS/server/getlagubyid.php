<?php
include_once("konfigurasi.php");

header("Content-Type: application/json; charset=utf-8");
$response = ["error" => 1, "data" => null];

if (isset($_GET["id_lagu"])) {
    $id = intval($_GET["id_lagu"]);
    $sql = "SELECT lagu.*, genre.nama_genre FROM lagu LEFT JOIN genre ON lagu.id_genre = genre.id_genre WHERE lagu.id_lagu = $id";
    $result = mysqli_query($koneksi, $sql);

    if ($result && mysqli_num_rows($result) > 0) {
        $response["error"] = 0;
        $response["data"] = mysqli_fetch_assoc($result);
    }
}

echo json_encode($response);
?>
