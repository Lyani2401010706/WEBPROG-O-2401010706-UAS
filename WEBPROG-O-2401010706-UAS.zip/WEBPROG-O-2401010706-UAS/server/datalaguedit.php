<?php
include_once("konfigurasi.php");

header("Content-Type: application/json; charset=utf-8");
$response = ["error" => 1];

if (isset($_POST["id_lagu"], $_POST["judul"], $_POST["artis"], $_POST["id_genre"])) {
    $id_lagu = intval($_POST["id_lagu"]);
    $judul = $_POST["judul"];
    $artis = $_POST["artis"];
    $id_genre = $_POST["id_genre"];
    $tahun = $_POST["tahun"] ?? null;
    $catatan = $_POST["catatan"] ?? null;

    $stmt = mysqli_prepare($koneksi, "UPDATE lagu SET judul = ?, artis = ?, id_genre = ?, tahun = ?, catatan = ? WHERE id_lagu = ?");
    mysqli_stmt_bind_param($stmt, "ssissi", $judul, $artis, $id_genre, $tahun, $catatan, $id_lagu);

    if (mysqli_stmt_execute($stmt)) {
        $response["error"] = 0;
    }
    mysqli_stmt_close($stmt);
}

echo json_encode($response);
?>
