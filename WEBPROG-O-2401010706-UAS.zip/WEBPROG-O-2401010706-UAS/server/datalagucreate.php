<?php
include_once("konfigurasi.php");

header("Content-Type: application/json; charset=utf-8");
$response = ["error" => 1];

if (isset($_POST["judul"], $_POST["artis"], $_POST["id_genre"])) {
    $judul = $_POST["judul"];
    $artis = $_POST["artis"];
    $id_genre = $_POST["id_genre"];
    $tahun = $_POST["tahun"] ?? null;
    $catatan = $_POST["catatan"] ?? null;

    $stmt = mysqli_prepare($koneksi, "INSERT INTO lagu (judul, artis, id_genre, tahun, catatan) VALUES (?, ?, ?, ?, ?)");
    mysqli_stmt_bind_param($stmt, "ssiss", $judul, $artis, $id_genre, $tahun, $catatan);

    if (mysqli_stmt_execute($stmt)) {
        $response["error"] = 0;
    }
    mysqli_stmt_close($stmt);
}

echo json_encode($response);
?>
