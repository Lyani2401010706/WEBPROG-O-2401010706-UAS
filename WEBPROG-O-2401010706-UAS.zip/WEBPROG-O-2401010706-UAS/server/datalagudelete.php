<?php
include_once("konfigurasi.php");

header("Content-Type: application/json; charset=utf-8");
$response = ["error" => 1];

if (isset($_POST["id_lagu"])) {
    $id = intval($_POST["id_lagu"]);
    $sql = "DELETE FROM lagu WHERE id_lagu = $id";
    $result = mysqli_query($koneksi, $sql);
    if ($result) {
        $response["error"] = 0;
    }
}

echo json_encode($response);
?>
