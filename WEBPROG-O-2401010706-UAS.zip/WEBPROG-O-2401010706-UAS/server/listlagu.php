<?php
include_once("konfigurasi.php");

header("Content-Type: application/json; charset=utf-8");
$data = [];
$sql = "SELECT lagu.*, genre.nama_genre FROM lagu LEFT JOIN genre ON lagu.id_genre = genre.id_genre ORDER BY lagu.id_lagu DESC";
$result = mysqli_query($koneksi, $sql);

while ($row = mysqli_fetch_assoc($result)) {
    $data[] = $row;
}

echo json_encode($data);
?>
