<?php
include_once("konfigurasi.php");

header("Content-Type: application/json; charset=utf-8");
$data = [];
$sql = "SELECT * FROM genre ORDER BY nama_genre";
$result = mysqli_query($koneksi, $sql);

while ($row = mysqli_fetch_assoc($result)) {
    $data[] = $row;
}

echo json_encode($data);
?>